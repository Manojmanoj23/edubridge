// src/com/blogapp/model/BlogPost.java

package com.blogapp.model;

public class Blog {
    private int id;
    private String title;
    private String content;
    private String dateCreated;

    // Constructor, getters, and setters
    public Blog(int id, String title, String content, String dateCreated) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.dateCreated = dateCreated;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }

    public void displayPost() {
        System.out.println("Title: " + title);
        System.out.println("Date Created: " + dateCreated);
        System.out.println("Content: " + content);
    }
}


// src/com/blogapp/exception/BlogAppException.java

package com.blogapp.exception;

public class BlogAppException extends Exception {
    public BlogAppException(String message) {
        super(message);
    }

    public BlogAppException(String message, Throwable cause) {
        super(message, cause);
    }
}


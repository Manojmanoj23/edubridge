// src/com/blogapp/mainpackage/BlogApp.java

package com.blogapp.mainpackage;

import com.blogapp.service.AdminService;
import com.blogapp.service.BlogSeviceInterface;
import com.blogapp.service.BlogServiceInterfaceImpl;
import com.blogapp.model.Blog;

import java.util.Scanner;

public class BlogApp {
    private static Scanner scanner = new Scanner(System.in);
    private static AdminService adminService = new AdminService();
    private static BlogSeviceInterface blogService = new BlogServiceInterfaceImpl();

    public static void main(String[] args) {
        boolean loggedIn = false;
        while (!loggedIn)//!true===false
        {
            loggedIn = loginAdmin();
        }

     //   boolean running = true;
        while (loggedIn) {
            displayMenu();
            int choice = scanner.nextInt();
          //  scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    blogService.viewAllBlogs().forEach(Blog::displayPost);
                    break;
                case 2:
                    createNewPost();
                    break;
                case 3:
                	loggedIn = false;
                    System.out.println("Exiting the blog application...");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static boolean loginAdmin() {
        System.out.print("Enter admin username: ");
        String username = scanner.nextLine();
        System.out.print("Enter admin password: ");
        String password = scanner.nextLine();

        if (adminService.validateAdmin(username, password)) {
            System.out.println("Login successful! Welcome, " + username + ".");
            return true;
        } else {
            System.out.println("Invalid username or password. Please try again.");
            return false;
        }
    }

    private static void displayMenu() {
        System.out.println("\n--- Blog Application ---");
        System.out.println("1. View all blog posts");
        System.out.println("2. Create a new blog post");
        System.out.println("3. Exit");
        System.out.print("Choose an option: ");
    }

    private static void createNewPost() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the ID:");
        int id = scanner.nextInt();
//        scanner.nextLine(); // Consume the newline character

        System.out.println("Enter the Title:");
        String title = scanner.next();

        System.out.println("Enter the Content:");
        String content = scanner.next();

        System.out.println("Enter the Date Created (yyyy-MM-dd):");
        String dateCreated = scanner.next();

        // Creating a Post object
        Blog newPost = new Blog(id, title, content, dateCreated);

        blogService.createNewBlog(newPost);
        // Display the Post object
        System.out.println("New Post Created: " + newPost);

        //scanner.close();
    }


}
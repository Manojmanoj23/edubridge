// src/com/blogapp/repository/BlogRepository.java

package com.blogapp.repository;

import com.blogapp.dbconfig.DatabaseConnection;
import com.blogapp.model.Blog;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BlogRepository {
    // Method to fetch all blog posts
    public List<Blog> getAllPosts() {
        List<Blog> posts = new ArrayList<>();
        String query = "SELECT * FROM blog_posts";
        
        try (Connection connection = DatabaseConnection.getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                int id = rs.getInt("id");
                String title = rs.getString("title");
                String content = rs.getString("content");
                String dateCreated = rs.getString("date_created");
                
                Blog post = new Blog(id, title, content, dateCreated);
                posts.add(post);
            }
        }  catch (SQLException e) {
            System.out.println("kljdlkjdlkjdlkjdl"+e.getMessage());
        }
        catch(IOException ex) {
        	System.out.println("7777777777777777777"+ex.getMessage());
        }

        return posts;
    }

    // Method to insert a new blog post
    public Blog createPost(Blog post) {
        String query = "INSERT INTO blog_posts (title, content,date_Created) VALUES (?, ?,?)";
        
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            
            stmt.setString(1, post.getTitle());
            stmt.setString(2, post.getContent());
            stmt.setString(3, post.getDateCreated());
           int rs= stmt.executeUpdate();
            if(rs>0) {
            System.out.println("New blog post created successfully.");
            return post;
            }
            else {
            	System.out.println("adding blog failed");
            	return null;
            }
            } catch (SQLException e) {
            System.out.println(e.getMessage());
            return null;
        }
        catch(IOException ex) {
        	System.out.println(ex.getMessage());
        	return null;
        }
    }
}


// src/com/blogapp/repository/AdminRepository.java

package com.blogapp.repository;

import java.io.IOException;
import java.sql.*;
import com.blogapp.dbconfig.DatabaseConnection;

public class AdminRepository {
    public boolean validateAdmin(String username, String password) {
        String query = "SELECT * FROM admin WHERE username = ? AND password = ?";
        
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
           if(rs.next())
           {
        	   return true;// If credentials match, return true
           }else
        	   return false;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
        catch(IOException ex) {
        	System.out.println(ex.getMessage());
        	return false;
        }
    }
}

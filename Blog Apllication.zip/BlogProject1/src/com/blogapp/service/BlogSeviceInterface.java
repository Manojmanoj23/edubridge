package com.blogapp.service;
import java.util.List;
import com.blogapp.model.*;

public interface BlogSeviceInterface {
Blog createNewBlog(Blog blog);
	List<Blog> viewAllBlogs();
}

// src/com/blogapp/service/BlogService.java

package com.blogapp.service;

import com.blogapp.model.Blog;
import com.blogapp.repository.BlogRepository;

import java.util.List;

public class BlogServiceInterfaceImpl implements BlogSeviceInterface {
    private BlogRepository blogRepository = new BlogRepository();

    public List<Blog> viewAllBlogs() {
        return blogRepository.getAllPosts();
    }

    public Blog createNewBlog(Blog blog) {
    	
        return blogRepository.createPost(blog);
        
    }

	
	
}

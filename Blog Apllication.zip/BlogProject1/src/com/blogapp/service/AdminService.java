// src/com/blogapp/service/AdminService.java

package com.blogapp.service;

import com.blogapp.repository.AdminRepository;

public class AdminService {
    private AdminRepository adminRepository = new AdminRepository();

    public boolean validateAdmin(String username, String password) {
        return adminRepository.validateAdmin(username, password);
    }
}


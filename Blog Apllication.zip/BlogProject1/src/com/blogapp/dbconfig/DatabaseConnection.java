// src/com/blogapp/dbconfig/DatabaseConnection.java

package com.blogapp.dbconfig;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {
    

    public static Connection getConnection() throws SQLException, IOException {
    	Properties properties = new Properties();
    	FileInputStream fis = new FileInputStream("db.properties");
    	properties.load(fis);
    	String url=properties.getProperty("URL");
    	String username=properties.getProperty("USER");
    	String password = properties.getProperty("PASSWORD");
    	System.out.println(url+" "+username+" "+password);
        Connection con =DriverManager.getConnection(url, username, password);
        return con;
    }
}
